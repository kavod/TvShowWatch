<?php
/**
 * Constants defined here outside of class because class constants can't be
 * the result of any operation (concatenation)
 */
define('TVDB_URL', 'http://thetvdb.com');
define('TVDB_API_KEY', 'A2894E6CB335E443');

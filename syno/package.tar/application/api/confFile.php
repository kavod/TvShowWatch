<?

class TvShowWatch
{
	var $filename;

	function TvShowWatch($filename = )
	{
		
	}
}

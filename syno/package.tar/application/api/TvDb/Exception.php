<?php

namespace Moinax\TvDb;


class Exception extends \Exception
{

}
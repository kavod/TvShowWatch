<?php

namespace Moinax\TvDb;


class XmlException extends Exception
{

}
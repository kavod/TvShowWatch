TvShowWatch
===========

Another TV Show download scheduler

### Install notice

Here are the dependencies:

+ ```tvdb_api``` - download and install from [here][1].
+ ```requests``` - run ```sudo pip install request```, see [this repo][2].
+ ```transmissionrpc``` - run ```easy_install transmissionrpc```, see [this repo][3]

[1]: https://github.com/dbr/tvdb_api
[2]: https://github.com/kennethreitz/requests
[3]: http://pythonhosted.org/transmissionrpc/
